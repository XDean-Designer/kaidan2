HeadLineA digit subset for local prototype matching.
CSS: font-family: "HeadLineA", "displayIdFont"; font-weight: 400;
Source app alias: displayIdFont
Real family: HeadLineA Regular (JCHEadA)
Apple copyright — not for production redistribution.
